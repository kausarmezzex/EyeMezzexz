﻿namespace EyeMezzexz.Models
{
    public class DecryptRequest
    {
        public string CipherText { get; set; }
    }
}
